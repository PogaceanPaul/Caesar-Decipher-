#include <iostream>
#include <fstream>
#include <map>
#include <cmath>
#include <cstring>
using namespace std;

ifstream fin("C:\\Users\\pogac\\CLionProjects\\OOP\\bonus1\\cmake-build-debug");

///-------------------------------------------------------------------------------------------------------------------
/// Write a function that reads the distribution of the letters from a file (distribution.txt) and stores it into an array.
/// The frequency of the letter ‘a’ is stored on the first line of the file (as a floating point number),
/// the frequency of the letter ‘b’ is stored on the second line of the file, etc.
void read_distribution(const char *filename, double distribution[27]) {
    fin.open(filename);
    if (!fin.is_open()) {
        cout << "Error opening file " << filename << endl;
        return;
    }
    for (int i = 1; i < 27; i++) {
        fin >> distribution[i];
    }
    fin.close();
}

///--------------------------------------------------------------------------------------------------------------------
/// Write a function that computes the normalized frequency of each character (a histogram) in a text.
void compute_histogram(const char* text, double histogram[27]) {
    int count = 0;
    int total = 0;
    memset(histogram, 0, 27 * sizeof(double));

    while (text[count] != '\0') {
        if (isalpha(text[count])) {
            char lower = tolower(text[count]);
            histogram[lower - 'a' + 1]++;
            total++;
        }
        count++;
    }

    if (total > 0) {
        for (int i = 1; i < 27; i++) {
            histogram[i] /= total;
        }
    }
}

///--------------------------------------------------------------------------------------------------------------------
/// Write a function that shifts the text by a given amount (Caesar cipher shift).
void caesar_shift(const char* text, char* shifted, int shift, int max_length) {
    int i = 0;
    while (text[i] != '\0' && i < max_length - 1) {
        if (isalpha(text[i])) {
            char base = isupper(text[i]) ? 'A' : 'a';
            shifted[i] = ((text[i] - base + shift + 26) % 26) + base;
        } else {
            shifted[i] = text[i];
        }
        i++;
    }
    shifted[i] = '\0';
}

///__________________________________________________________________________________________________
/// Write a function that computes the Chi-square distance between two histograms.
double chi_squared_distance(const double x[], const double y[]) {
    double chi_squared = 0.0;
    for (int i = 0; i < 26; i++) {
        if (y[i] != 0) {
            chi_squared += (x[i] - y[i]) * (x[i] - y[i]) / y[i];
        }
    }
    return chi_squared;
}

///__________________________________________________________________________________________________
/// Write a function that computes the Euclidian distance between two histograms.
double euclidian_distance(const double x[], const double y[]) {
    double euclidian_distance = 0.0;
    for (int i = 0; i < 26; i++) {
        euclidian_distance += pow((x[i] - y[i]), 2);
    }
    return sqrt(euclidian_distance);
}

///__________________________________________________________________________________________________
/// Write a function that computes the Cosine distance between two histograms.
double cosine_distance(const double x[], const double y[]) {
    double dot_product = 0.0;
    double normx = 0.0;
    double normy = 0.0;
    for (int i = 0; i < 26; i++) {
        dot_product += x[i] * y[i];
        normx += x[i] * x[i];
        normy += y[i] * y[i];
    }
    double cosine_similarity = dot_product / (sqrt(normx) * sqrt(normy));
    return 1 - cosine_similarity;
}

///__________________________________________________________________________________________________
/// Write a function that breaks the Caesar’s cipher using frequency analysis.
/// The function should try all possible shifts, compute the letter frequency histogram for each shifted text,
/// compare it to the standard English letter distribution using a distance function (passed as a parameter),
/// and return the top shift with the lowest distance.
void break_caesar_cipher(const char* text, double english_distribution[27], double (*distance_function)(const double[], const double[])) {
    char shifted_text[1000];
    char decrypted_text[1000];
    double histogram[27];
    int best_shift = 0;
    double best_distance = 1000000;

    for (int shift = 0; shift < 26; shift++) {
        caesar_shift(text, shifted_text, shift, 1000);
        compute_histogram(shifted_text, histogram);

        double distance = distance_function(histogram, english_distribution);

        cout << "Shift: " << shift << ", Distance: " << distance << endl;

        if (distance < best_distance) {
            best_distance = distance;
            best_shift = shift;
        }
    }

    caesar_shift(text, decrypted_text, best_shift, 1000);

    cout << "Best shift: " << best_shift << endl;
    cout << "Decrypted text: " << decrypted_text << endl;
}

int main() {
    double distribution[27] = {0};
    char text[1000] = "";
    int choice;
    int shift;

    // Read the distribution file
    char filename[100];
    cout << "Enter the path to the distribution file (e.g., distribution.txt): ";
    cin >> filename;
    read_distribution(filename, distribution);
    while (true) {
        cout << "\nMenu:\n";
        cout << "1. Read text from keyboard\n";
        cout << "2. Read text from file\n";
        cout << "3. Encrypt text with a shift\n";
        cout << "4. Decrypt text with a known shift\n";
        cout << "5. Compute and display frequency distribution\n";
        cout << "6. Break Caesar cipher using frequency analysis\n";
        cout << "7. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        cin.ignore(); // Clear the input buffer

        if (choice == 1) {
            cout << "Enter text: ";
            cin.getline(text, 1000);
        }
        else if (choice == 2) {
            char input_filename[100];
            cout << "Enter filename: ";
            cin >> input_filename;
            ifstream input_file(input_filename);
            if (input_file) {
                input_file.getline(text, 1000);
                input_file.close();
                cout << "Text read from file successfully.\n";
            } else {
                cout << "Error opening file.\n";
            }
        }
        else if (choice == 3) {
            cout << "Enter shift: ";
            cin >> shift;
            char encrypted[1000];
            caesar_shift(text, encrypted, shift, 1000);
            cout << "Encrypted text: " << encrypted << endl;
            strncpy(text, encrypted, 1000); // Update the original text
        }
        else if (choice == 4) {
            cout << "Enter shift: ";
            cin >> shift;
            char decrypted[1000];
            caesar_shift(text, decrypted, -shift, 1000);
            cout << "Decrypted text: " << decrypted << endl;
            strncpy(text, decrypted, 1000); // Update the original text
        }
        else if (choice == 5) {
            double histogram[27];
            compute_histogram(text, histogram);
            for (char c = 'a'; c <= 'z'; c++) {
                cout << c << ": " << histogram[c - 'a' + 1] * 100 << "%\n";
            }
        }
        else if (choice == 6) {
            int distance_choice;
            cout << "Choose a distance function:\n";
            cout << "1. Chi-square distance\n";
            cout << "2. Euclidean distance\n";
            cout << "3. Cosine distance\n";
            cout << "Enter your choice: ";
            cin >> distance_choice;

            double (*distance_function)(const double[], const double[]) = nullptr;
            switch (distance_choice) {
                case 1:
                    distance_function = chi_squared_distance;
                    break;
                case 2:
                    distance_function = euclidian_distance;
                    break;
                case 3:
                    distance_function = cosine_distance;
                    break;
                default:
                    cout << "Invalid choice. Using Chi-square distance by default.\n";
                    distance_function = chi_squared_distance;
                    break;
            }

            break_caesar_cipher(text, distribution, distance_function);
        }
        else if (choice == 7) {
            cout << "Exiting...\n";
            break;
        }
        else {
            cout << "Invalid choice. Please try again.\n";
        }
    }

    return 0;
}